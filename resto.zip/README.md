# Restaurant Order Booking Website

A mobile-first restaurant order booking website built with PHP and JSON backend, designed to match the provided mobile UI design pixel-perfectly.

## Features

- **Mobile-First Design**: Pixel-perfect match to the provided design
- **JSON Backend**: All data stored in JSON files (menu, orders, favorites)
- **Cart Management**: Add items to cart with quantity controls
- **Order Placement**: Complete checkout process with delivery details
- **Favorites**: Save favorite food items
- **Search & Filter**: Search by name and filter by category
- **Order History**: View past orders with status tracking

## Project Structure

```
├── index.php           # Home page with menu items
├── cart.php           # Shopping cart page
├── checkout.php       # Checkout page
├── orders.php         # Order history page
├── css/
│   ├── style.css      # Main styles
│   ├── cart.css       # Cart page styles
│   ├── checkout.css   # Checkout page styles
│   └── orders.css     # Orders page styles
├── js/
│   ├── script.js      # Main JavaScript
│   ├── cart.js        # Cart functionality
│   └── checkout.js    # Checkout functionality
├── api/
│   ├── add-to-cart.php
│   ├── update-cart.php
│   ├── remove-from-cart.php
│   ├── filter-menu.php
│   ├── search.php
│   ├── toggle-favorite.php
│   └── place-order.php
├── data/
│   ├── menu.json      # Menu items
│   ├── orders.json    # Order history
│   └── favorites.json # Favorite items
└── assets/            # Images (add your own)
```

## Setup Instructions

1. **Requirements**:
   - PHP 7.4 or higher
   - Web server (Apache/Nginx) or PHP built-in server

2. **Installation**:
   ```bash
   # Clone or download the project
   # Navigate to project directory
   cd restaurant-booking
   ```

3. **Add Images**:
   Create an `assets` folder and add the following images:
   - profile.jpg (user profile picture)
   - pasta.jpg (promo banner)
   - burger.jpg, pizza.jpg, fries.jpg, chicken.jpg, pizza2.jpg (category icons)
   - fried-chicken.jpg (food item images)

4. **Run the Application**:
   ```bash
   # Using PHP built-in server
   php -S localhost:8000
   ```

5. **Access**:
   Open your browser and navigate to `http://localhost:8000`

## Mobile Design Features

- **Status Bar**: Shows time, signal, WiFi, and battery
- **Header**: Profile picture, location selector, notification bell
- **Search Bar**: With filter button
- **Promo Banner**: 27% discount banner with food image
- **Categories**: Horizontal scrollable category icons
- **Food Cards**: With images, discount badges, favorite button, and add to cart
- **Bottom Navigation**: 5 navigation items with active state

## Responsive Design

The design is optimized for mobile devices (430px width) but adapts to smaller screens. The layout maintains the exact look and feel of the provided design.

## Data Management

All data is stored in JSON files:
- **menu.json**: Food items with prices, categories, and images
- **orders.json**: Order history with customer details
- **favorites.json**: User's favorite items

## Browser Support

- Chrome (recommended)
- Safari
- Firefox
- Edge

## Notes

- Session-based cart management
- No database required
- Easy to customize and extend
- Production-ready with proper error handling
